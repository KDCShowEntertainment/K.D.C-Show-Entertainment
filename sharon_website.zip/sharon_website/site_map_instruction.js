            var site_info_instruction = document.location.href.split("?");
                            if(site_info_instruction.length == 2 ){
                                site_info_instruction = site_info_instruction[1]
                            }